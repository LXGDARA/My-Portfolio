package performers;

import logic.Random;

/**
 * YOU NEED TO WRITE THE JAVADOC. Write doc comments for all methods.
 * 
 * @author YOUR NAME HERE
 *
 */
public class Wizard extends Player {
	
	public Wizard() {
		// *If* you call the superclass constructor, make sure you call it first.
		super(
			Random.rand(50) + 10,  // hitPoints
			Random.rand(20) + 5,   // strength is within [5, 25)
			Random.rand(100) + 20 // wisdom is within [20, 100)
		);
		// Then initialize other variables after...
	}
	
	@Override
	public String[] attack(Monster... monsters) {
		String[] results = new String[monsters.length + 1];
		int i = 0;
		results[i++] = "Wizard attack!";
		
		// Randomly damage each monster passed in.
		for (Monster mnstr : monsters) {
			// Design your own calculations.
			int damage = Random.rand(strength) + 2;
			mnstr.damageHitPoints(damage);
			// Describe stats on this monster.
			results[i++] = 
				"- hit " + 
				mnstr.getDescription() + 
				" with " + 
				damage + 
				" damage;" +
				" it has " + 
				mnstr.getHitPoints() +
				" hit points remaining.";
		}
		
		return results;
	}

	@Override
	public String[] castSpell(Monster... monsters) {
		return new String[] { "Wizard spell!" };
	}

}
