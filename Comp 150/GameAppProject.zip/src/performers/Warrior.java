package performers;

import logic.Random;

/**
 * YOU NEED TO WRITE THE JAVADOC. Write doc comments for all methods.
 * 
 * @author YOUR NAME HERE
 *
 */
public class Warrior extends Player {
	
	public Warrior() {
		// *If* you call the superclass constructor, make sure you call it first.
		super(
			MAX_HIT_POINTS,  // hitPoints start with the max
			Random.rand(80) + 20, // strength is within [20, 100)
			Random.rand(20) + 5   // wisdom is within [5, 25)
		);
		// Then initialize other variables after...
	}
	
	@Override
	public String[] attack(Monster... monsters) {
		// Recall that ... is called "variable arguments" (textbook, pg 93).
		// Basically, you can use monsters like an array of strings.
		return new String[] { "Warrior attack! " + strength };
	}

	@Override
	public String[] castSpell(Monster... monsters) {
		return new String[] { "Warrior spell!" };
	}

}
