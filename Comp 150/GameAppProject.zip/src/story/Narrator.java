package story;

import java.util.Arrays;

import logic.DataManager;

/**
 * This class takes care of describing what is happening in the story events of our game.
 * It is much easier to keep track of all the parts of our story in one place: this class.
 */
public class Narrator {
	// There is only one interactive story, so all methods are static.
	private final static int FINAL_CHAPTER = 2;
	private static int chapter = 0;
	private static DataManager data;
	
	// If everything is static, then we never need a constructor.
	// All variables only store one primitive value, or one instance of an object.
	// All methods can execute on the shared variables above.
	
	/**
	 * Connect to the same data instance used by the Game. So the Narrator can know
	 * what the player's name is, and whether they have died or not.
	 * 
	 * @param data
	 *   Should pass in the same data instance used by the Game.
	 */
	public static void setData(DataManager data) {
		Narrator.data = data; // instance shared by Game, Narrator
	}
	
	/**
	 * A method to get the different parts of our story. Each time this method is
	 * executed, the chapter number advances by one value. Extend the given code,
	 * or you could design your story to behave in a completely different way if 
	 * you want. For example, creating descriptions of your story or character 
	 * dialogue as strings in an array or collection, and choosing parts of it 
	 * in different ways, perhaps partly random.
	 *
	 * @return
	 *   An array of string descriptions.
	 */
	public static String[] tell() {
		if (data.isPlayerChosen() && data.isPlayerDead()) {
			chapter = FINAL_CHAPTER;
		}
		
		switch (chapter++) {
			case 0:
				return begin();
			case 1:
				return chapter1();
			case FINAL_CHAPTER:
				return end();
			default:
				return new String[] { "Done telling a story. (debug)" };
		}
	}
	
	// The start of the story.
	private static String[] begin() {
		/* 
		 * String of dashes below is example of maximum length line we can have in
		 * a Billboard (62 chars) it is designed this way in the Billboard code by way
		 * of throwing Exceptions. This forces other programmers to follow your
		 * method designs and get useful debug error messages that are expected from
		 * taking advantage of exceptions.
		 *  "--------------------------------------------------------------"
		 */
		String[] intro = {
			"Hello, " + data.getUserName() + "!",
			"--- GET READY TO HAVE AN AMAZING EXPERIENCE ---",
			"", // a blank line
			"You are in a dark dungeon full of monsters.",
			"The only way out is to survive!"
		};
		return intro;
	}
	
	// You could give your own methods useful scene names to help yourself
	// keep track of what parts of your story are about and their order.
	private static String[] chapter1() {
		String[] prose = {
			"You are enjoying a nice hike up a rocky mountain on",
			"a beautiful, sunny day. Around the next boulder, you see a",
			"a primitive brick wall with a dark opening, blocked",
			"by an iron-bar gate---its bars bent wide",
			"enough for you to enter...",
			"",
			"Inside is a dungeon looking very dank, with a smell",
			"of sulpher. You look up to see long stalactites and",
			"hear only a few dripping sounds.",
			"",
			"A sudden RUMBLE! The gate behind you is blocked by a",
			"rock avalanche. It is so dark now, but you can see a",
			"dim light in the distance. Strange noises of scurrying",
			"and squeeking echo from all sides of you.",
			"",
			"You see a group of monsters!",
			""
		};
		prose = combine(prose, data.describeMonsters());
		return prose;
	}
	
	// Two simple and different ways the game can end.
	private static String[] end() {
		String[] ending;
		if (data.isPlayerDead()) 
			ending = new String[] { // you are expected to write more...
				"Your player has died...",
				"Thank you for playing!"
			};
		else
			ending = new String[] { // you are expected to write more...
				"And they all lived happily ever after.",
				"Thank you for playing!"
			};
		return ending;
	}
	
	/**
	 * Checks if the Narrator is ready to end its story.
	 * This helps Game know what to do next. Perhaps you
	 * could check similarly for other chapters?
	 *
	 * @return
	 *   Returns <code>true</code> if the Narrator is currently about 
	 *   to tell the final chapter in the story, and <code>false</code> otherwise.
	 */
	public static boolean isAtFinalChapter() {
		return chapter == FINAL_CHAPTER;
	}
	
	// A helper method to sequence together two string arrays into one array.
	private static String[] combine(String[] first, String[] second) {
		// Copy the first, and make enough extra space for the second.
		String[] combined = Arrays.copyOf(first, first.length + second.length);
		// Copy the second into the extra space.
		System.arraycopy(second, 0, combined, first.length, second.length);
		return combined;
	}
	
	/*
	 * Maybe you could design your own line-breaking method to create arrays of Strings
	 * in a much more efficient way than I have done above? Pass in a String, choose how
	 * to partition it, and return an array of Strings. It may help you design a story
	 * in your code much faster instead of writing chapters of it inside String arrays
	 * like I did above.
	 */
}