/**
 * This Class holds all 4 of our methods used to attain the desired output
 * @author Dara Adekore
 */
public class Solutions {
	// you could print these to output to get a better idea what you are working with
	final static String TEXT =
		"it was so long since she had been anything near the right size that it felt quite strange at first but she got used to it in a few minutes and began talking to herself as usual. come theres half my plan done now. how puzzling all these changes are. im never sure what im going to be from one minute to another. however ive got back to my right size the next thing is to get into that beautiful garden how is that to be done I wonder. as she said this she came suddenly upon an open place with a little house in it about four feet high. whoever lives there thought alice itll never do to come upon them this size why, I should frighten them out of their wits. So she began nibbling at the righthand bit again and did not venture to go near the house till she had brought herself down to nine inches high.";
	// if you want to print these, loop to print them, one element each iteration
	final static String[] SENTENCES = TEXT.split("\\."); // regular expressions are a bit different for escaping characters
	final static String[] WORDS = TEXT.split(" ");
	Random myRandom = new Random();
	// MUST DO: remove any unnecessary printed output before submitting

	// --- the variables of a class do not get doc comments; describe them in the class doc comment if needed ---
	// --- DO NOT PASS ANY ARGUMENTS TO PARAMETERS FOR YOUR METHODS
	// --- call your four methods in Program.java
	
	/**
	 *
	 * MyDataType method returns the max value capable of being stored in the known data type.
	 */
	public void MyDataType() {
		
		int myPrimByte = (int)Math.pow(2,7);
		int myPrimShort = (int)Math.pow(2, 15);
		int myPrimInt = (int)Math.pow(2, 31);
		long myPrimLong = (long)Math.pow(2,63);
		float myMinFloat = Float.MIN_VALUE, myMaxFloat = Float.MAX_VALUE;
		double myMinDouble = Double.MIN_VALUE, myMaxDouble = Double.MAX_VALUE;
		int myMinChar = Character.MIN_VALUE, myMaxChar = Character.MAX_VALUE;
		System.out.println("Char: " + ( myPrimByte*-1) + " " + (myPrimByte - 1));
		System.out.println("Short: " + (myPrimShort*-1) + " " + (myPrimShort - 1));
		System.out.println("Int: " + (myPrimInt*-1) + " " + (myPrimInt- 1));
		System.out.println("long: " + (myPrimLong*-1) + " " + (myPrimLong - 1));
		System.out.println("Float: " + myMinFloat + " " + myMaxFloat);
		System.out.println("Double: " + myMinDouble + " " + myMaxDouble);
		System.out.println("Char: " + myMinChar + " " + myMaxChar);
		
	}
	/**
	 *
	 *  returns a block of * with pseudorandomized dimmensions width x height
	 along with with values of width & height.
	 */
	public void MyCharBloc() {
		int myWidth = myRandom.rand(70) + 10;// the 10 is added to ensure that if we ever get 0, it will actually be 10
		int myHeight = myRandom.rand(20) + 10;
		for(int j = 0; j<myHeight; j++) {
			for(int i = 0; i<myWidth; i++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("Width: " + myWidth + " " + "myHeight: " + myHeight);
	}
/**
 *
 * Returns the most # of words in a given sentence and then the sentence itself.
 */
	public void MyWordCount() {
		
		int myTally = 0;

		int maxWord = 0;
		String maxSent = null;
		for(int i = 0; i < SENTENCES.length; i++) {
			for(int j = 0; j < SENTENCES[i].length(); j++) {
				if(SENTENCES[i].charAt(j) == ' ') {
					myTally++;
				}	
			}
			if(myTally > maxWord) {
				maxWord = myTally;
				maxSent = SENTENCES[i];
				
			}
			myTally = 0;
		}
		System.out.println("The maximum # of words in a sentence is : " + (maxWord-1));
		System.out.println("The sentence with the most amount of words is: " + maxSent);
	}
	/**
	 * 
	 * @return 0 &  Returns an output of the entire paragraph, with a new line starting at 50 word intervals.
	 */
	public void  myWordLmt() {
		
		int wordCntr;
		for(wordCntr = 0; wordCntr<WORDS.length; wordCntr++) {
			if(wordCntr%50 == 0) {
				System.out.println("\n");
			}
			System.out.print(WORDS[wordCntr] + " ");
		}
	}
}
	


 // MUST DO: command line Javadac generation:
 // javadoc *.java -d doc -package
 // Remember to write a doc comment for each method to describe it.
 // You should not need any Javadoc tags for this first assignment.
