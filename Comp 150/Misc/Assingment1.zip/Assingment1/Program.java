/**
 * This Class is holds our main a.k.a our entry point into the program. 
 * Inside, are the methods from the Solutions class, referenced by the created "myObj" object
 * @author Dara Adekore
 *
 */
public class Program {

	public static void main(String[] args) {
		Solutions myObj = new Solutions();
		myObj.MyDataType();
		myObj.MyCharBloc();
		myObj.MyWordCount();
		myObj.myWordLmt();
	}

}
