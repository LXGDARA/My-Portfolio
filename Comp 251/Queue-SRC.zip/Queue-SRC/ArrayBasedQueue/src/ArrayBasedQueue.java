import java.util.NoSuchElementException;

public class ArrayBasedQueue<AnyType> {

	private static int MAX_SIZE = 1000;  // initial array size
	private AnyType[] items;         // array to keep items in the queue
	private int front;                // indicates the index of front in queue
	private int count;				//the number of items in queue
	
	/**
	 *  ArrayBasedQueue() constructs an empty queue.
	 */
	public ArrayBasedQueue(){ 
		items = (AnyType[]) new Object[MAX_SIZE];
	    front = 0;
	    count = 0;
	}

	/**
	 * @return the number of items in this queue
	 */
	public int size() {
		return count;
	}
	  
	/**
	 * Tests if the queue contains no element
	 * @return true if the queue contains no element
	 */
	public boolean isEmpty() {
	    return count == 0;
	}
	
	/**
	 * An internal method to expand the size of array items
	 * Allocates a new array, twice as long.
	 * Updates the MAX_SIZE
	 */
	private void expand() {
		//To be implemented!!  
	}

	
	/**
	 * insert an item to the queue (rear of the queue)
	 * @param x any object
	 */
	public void enqueue(AnyType x) {
		if (size() == MAX_SIZE) 
			expand();
		int rear = (front+count) % MAX_SIZE;
	    items[rear] = x;
	    count++;
	}
	  
	  
	/**
	 * Returns the item at the front of queue
	 * @return return the data of the item at front
	 * @throws NoSuchElementException if queue is empty
	 */
	public AnyType peek() throws NoSuchElementException {
		if (isEmpty())
			throw new NoSuchElementException(); 
		  
		return items[front];
	}
	  
	/**
	 * Removes and returns the front element of queue. 
	 * @return the front element of the queue
	 * @throws NoSuchElementException if queue is empty
	 */
	public AnyType dequeue() throws NoSuchElementException {
		if (isEmpty())
			throw new NoSuchElementException();
		AnyType x = items[front];
		front = (front+1) % items.length;
		count--;
		return x;
	}
	  
	public String toString() {
		int ind, i;
		AnyType obj;
		String result = "[  ";
		  
        ind = front;
        i = 0;
		while (i < count) {
		    obj = items[ind];
		    result = result + obj.toString() + "  ";
		    i++;
		    ind = (ind+1) % MAX_SIZE;
		}
		result = result + "]";
		return result;
	}
	
	
	public static void main (String[] args) {
	    test();    
	}
	
	  /**
	   *  test() tests toString(), isEmpty(), size(), enqueue(),
	   *  dequeue() and peek().  Prints summary information of the 
	   *  tests and halts the program if errors are detected.
	   **/

	  private static void test() {
	    ArrayBasedQueue<Integer> s1 = new ArrayBasedQueue<Integer>();
	    s1.enqueue(new Integer(3));
	    System.out.println();
	    System.out.println("Here is a queue after enqueue(3) to an empty queue: "
			       + s1);
	    System.out.println("Here is the top item on queue: "
			       + s1.peek());
	    s1.enqueue(new Integer(5)); 
	    s1.enqueue(new Integer(1)); 
	    s1.enqueue(new Integer(2));
	    System.out.println("Here is the queue after inserting 5, 1, 2: " + s1);
	    System.out.println("The queue should be: [  3  5  1  2  ]");
	    System.out.println("Here is the item at front of queue: "
			       + s1.peek() + ", it should be: 3");
	    s1.dequeue(); 
	    s1.dequeue();
	    System.out.println("Here is the queue after two dequeue " + s1);
	    System.out.println("The queue should be: [  1  2  ]");
	    System.out.println("Here is the item at front of queue: "
			       + s1.peek() + ", it should be: 1");
	    s1.enqueue(new Integer(7));
	    System.out.println("Here is the queue after inserting 7: " + s1);
	    System.out.println("The queue should be: [  1  2  7  ]");
	    System.out.println("Here is the item at front of queue: "
			       + s1.peek() + ", it should be: 1");
	  }


}
