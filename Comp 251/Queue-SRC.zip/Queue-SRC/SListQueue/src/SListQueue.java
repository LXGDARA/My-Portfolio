import java.util.NoSuchElementException;

public class SListQueue<AnyType> {
	private SListNode<AnyType> front;     // front of the queue.
	private SListNode<AnyType> rear;     // back/rear of the queue.
	private int size;                   // Number of items in queue.

	public SListQueue() {     // Here's how to create an empty queue.
		front = null;
		rear = null;
		size = 0;
	}
	  
	/**
	 * @return the number of items in this queue
	 */
	public int size() {
		return size;
	}
	  
	/**
	 * Tests if the queue contains no element
	 * @return true if the queue contains no element
	 */
	public boolean isEmpty(){
		return (size() == 0);
	}

	/**
	 * Returns the item at the front of queue
	 * @return return the data of the item at front
	 * @throws NoSuchElementException if queue is empty
	 */
	public AnyType peek() throws NoSuchElementException {
		if (isEmpty())
			throw new NoSuchElementException(); 
		  
		return front.item;
	}

	
	/**
	 * insert an item to the queue (rear of the queue or 
	 * at the tail of the linkedlist)
	 * @param x any object
	 */
	public void enqueue(AnyType x) {
		SListNode<AnyType> newNode = new SListNode<AnyType>(x);
		if (rear == null) {
			rear = newNode;
			front = rear;
		}
		else {
			rear.next = newNode;
			rear = newNode;
		}
		size++;
	}

	/**
	 * Removes and returns the front element of queue. 
	 * @return the front element of the queue
	 * @throws NoSuchElementException if queue is empty
	 */
	public AnyType dequeue() throws NoSuchElementException {
		if (isEmpty())
			throw new NoSuchElementException();
		AnyType item = front.item;
		front = front.next;
		if (front == null)
			rear = null;
		size--;
		return item;
	}
	  
	public String toString() {
		String result = "[ ";
		SListNode<AnyType> curr = front;
		while (curr != null) {
			result += curr.item + " ";
			curr = curr.next;
		}
		result += "]";
		return result;
	}
	
	  public static void main (String[] args) {
			
		    test();
		    
		  }

		    
		  /**
		   *  test() tests toString(), isEmpty(), size(), enqueue(),
		   *  dequeue() and peek().  Prints summary information of the 
		   *  tests and halts the program if errors are detected.
		   **/

		  private static void test() {
		    SListQueue<Integer> s1 = new SListQueue<Integer>();
		    s1.enqueue(new Integer(3));
		    System.out.println();
		    System.out.println("Here is a queue after enqueue(3) to an empty queue: "
				       + s1);
		    System.out.println("Here is the top item on queue: "
				       + s1.peek());
		    s1.enqueue(new Integer(5)); 
		    s1.enqueue(new Integer(1)); 
		    s1.enqueue(new Integer(2));
		    System.out.println("Here is the queue after inserting 5, 1, 2: " + s1);
		    System.out.println("The queue should be: [  3  5  1  2  ]");
		    System.out.println("Here is the item at front of queue: "
				       + s1.peek() + ", it should be: 3");
		    s1.dequeue(); 
		    s1.dequeue();
		    System.out.println("Here is the queue after two dequeue " + s1);
		    System.out.println("The queue should be: [  1  2  ]");
		    System.out.println("Here is the item at front of queue: "
				       + s1.peek() + ", it should be: 1");
		    s1.enqueue(new Integer(7));
		    System.out.println("Here is the queue after inserting 7: " + s1);
		    System.out.println("The queue should be: [  1  2  7  ]");
		    System.out.println("Here is the item at front of queue: "
				       + s1.peek() + ", it should be: 1");
		  }

}
