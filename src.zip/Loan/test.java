import java.io.IOException;

public class test {

	/*
	 * when you are done with updating PriorityQueue remove method main from
	 * PriorityQueue and uncomment this method
	 */
	/*
	*/
	public static void main(String[] args) throws IOException
    {
		Loan testObject = new Loan();
		testObject.run();
    }
    

}
