 Key things to note:
-I used the example of $300000 which gave the predicted outcome in the text files ; For this I loaded, set budget, decided and printed.
- Afterwards I gave John smith 10 years of experience, I then updated, set the budget , decided and printed